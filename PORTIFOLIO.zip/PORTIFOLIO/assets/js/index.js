const menuToggle=document.querySelector('.menu-toggle');
const navLinks=document.querySelector('#nav-links');
menuToggle?.addEventListener('click',()=>{const open=navLinks.classList.toggle('open');menuToggle.setAttribute('aria-expanded',open)});
document.querySelectorAll('#nav-links a').forEach(a=>a.addEventListener('click',()=>{navLinks.classList.remove('open');menuToggle?.setAttribute('aria-expanded','false')}));
const sections=[...document.querySelectorAll('main section[id]')];
const navItems=[...document.querySelectorAll('.nav-links a[href^="#"]')];
const updateNav=()=>{const y=window.scrollY+140;let current='home';sections.forEach(s=>{if(y>=s.offsetTop)current=s.id});navItems.forEach(a=>a.classList.toggle('active',a.getAttribute('href')==='#'+current))};
window.addEventListener('scroll',updateNav,{passive:true});updateNav();

const observer=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting)e.target.classList.add('visible')}),{threshold:.12});
document.querySelectorAll('.reveal').forEach(el=>observer.observe(el));

document.querySelectorAll('.filter').forEach(button=>button.addEventListener('click',()=>{
 document.querySelectorAll('.filter').forEach(b=>b.classList.remove('active'));button.classList.add('active');
 const filter=button.dataset.filter;
 document.querySelectorAll('.project').forEach(card=>{card.style.display=(filter==='all'||card.dataset.category.split(' ').includes(filter))?'':'none'});
}));



function nillahOpenTalkModal(event) {

    event.preventDefault();

    const modal = document.getElementById("nillahTalkModal");

    modal.classList.add("nillah-talk-visible");

    document.body.style.overflow = "hidden";
}


function nillahCloseTalkModal() {

    const modal = document.getElementById("nillahTalkModal");

    modal.classList.remove("nillah-talk-visible");

    document.body.style.overflow = "";
}


/* Close when clicking outside the card */
document
    .getElementById("nillahTalkModal")
    .addEventListener("click", function(event) {

        if (event.target === this) {
            nillahCloseTalkModal();
        }

    });


/* Close with ESC */
document.addEventListener("keydown", function(event) {

    if (event.key === "Escape") {
        nillahCloseTalkModal();
    }

});


(function () {

    const preloader =
        document.getElementById("nillah-preloader");

    if (!preloader) return;


    function hideNillahPreloader() {

        preloader.classList.add("nillah-loaded");

        // Remove it completely after the fade animation
        setTimeout(function () {

            preloader.remove();

        }, 800);

    }


    // Wait until the complete website has loaded
    window.addEventListener("load", function () {

        // Small delay makes the animation feel intentional
        setTimeout(function () {

            hideNillahPreloader();

        }, 700);

    });

})();